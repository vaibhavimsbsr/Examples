package com.gce.supermarket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SuperMarketMainApplication {

	public static void main(String[] args) {
		SpringApplication.run(SuperMarketMainApplication.class, args);
	}
}
