package com.gce.supermarket.bootstrap;

import com.gce.supermarket.model.SuperMarket;
import com.gce.supermarket.repository.SuperMarketRepository;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

@Component
public class SpringJpaBootstrap implements ApplicationListener<ContextRefreshedEvent> {

	private SuperMarketRepository superMarketRepository;
	
	private Logger log = LogManager.getLogger(SpringJpaBootstrap.class);
	
	@Autowired
    public void setSuperMarketRepository(SuperMarketRepository superMarketRepository) {
        this.superMarketRepository = superMarketRepository;
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        loadSuperMarkets();
    }

    private void loadSuperMarkets() {
        SuperMarket superMarket1 = new SuperMarket();
        superMarket1.setShopName("Kroger");
        superMarket1.setCategory("Mall");
        superMarket1.setAddress("5 Commerce Way, Auburn, NY 13021, USA ");
        superMarket1.setOwnerName("Ulrich Starker");
        superMarketRepository.save(superMarket1);

        log.info("Saved SuperMarket - id: " + superMarket1.getId());

        SuperMarket superMarket2 = new SuperMarket();
        superMarket2.setShopName("Publix");
        superMarket2.setCategory("Super Market");
        superMarket2.setAddress("5 Commerce Way, Auburn, NY 13021, USA ");
        superMarket2.setOwnerName("Ulrich Starker");
        superMarketRepository.save(superMarket2);
        log.info("Saved SuperMarket - id: " + superMarket2.getId());
        
        SuperMarket superMarket3 = new SuperMarket();
        superMarket3.setShopName("HEB");
        superMarket3.setCategory("Grocery Company");
        superMarket3.setAddress("304 W El Camino Real Sunnyvale");
        superMarket3.setOwnerName("Michael");
        superMarketRepository.save(superMarket3);
        log.info("Saved SuperMarket - id: " + superMarket3.getId());
        
        SuperMarket superMarket4 = new SuperMarket();
        superMarket4.setShopName("Ammons Supermarket");
        superMarket4.setCategory("Super Market");
        superMarket4.setAddress("143 Bridgeton Pike Mantua");
        superMarket4.setOwnerName("Jon");
        superMarketRepository.save(superMarket4);
        log.info("Saved SuperMarket - id: " + superMarket4.getId());
        
        SuperMarket superMarket5 = new SuperMarket();
        superMarket5.setShopName("Baraboo Sysco");
        superMarket5.setCategory("Company");
        superMarket5.setAddress("910 South Blvd Baraboo");
        superMarket5.setOwnerName("Aaron Fujimoto");
        superMarketRepository.save(superMarket5);

        log.info("Saved SuperMarket - id: " + superMarket5.getId());
    }
}
