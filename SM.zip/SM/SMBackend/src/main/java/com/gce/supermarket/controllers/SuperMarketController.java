package com.gce.supermarket.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.gce.supermarket.model.SuperMarket;
import com.gce.supermarket.services.SuperMarketService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/supermarket")
@Api(value = "onlinestore", description = "Operations pertaining to super market")
public class SuperMarketController {

	private SuperMarketService superMarketService;

	@Autowired
	public void setSuperMarketService(SuperMarketService superMarketService) {
		this.superMarketService = superMarketService;
	}

	@ApiOperation(value = "View a list of available super market", response = Iterable.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	@RequestMapping(value = "/list", method = RequestMethod.GET, produces = "application/json")
	public Iterable<SuperMarket> list(Model model) {
		Iterable<SuperMarket> superMarketList = superMarketService.listAllSuperMarket();
		return superMarketList;
	}

	@ApiOperation(value = "Search a supermarket with an ID", response = SuperMarket.class)
	@RequestMapping(value = "/show/{id}", method = RequestMethod.GET, produces = "application/json")
	public SuperMarket showSuperMarket(@PathVariable Integer id, Model model) {
		SuperMarket supermarket = superMarketService.getSuperMarketById(id);
		return supermarket;
	}

	@ApiOperation(value = "Add a supermarket")
	@RequestMapping(value = "/add", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity saveSuperMarket(@RequestBody SuperMarket supermarket) {
		superMarketService.saveSuperMarket(supermarket);
		return new ResponseEntity("SuperMarket saved successfully", HttpStatus.OK);
	}

	@ApiOperation(value = "Update a supermarket")
	@RequestMapping(value = "/update/{id}", method = RequestMethod.PUT, produces = "application/json")
	public ResponseEntity updateSuperMarket(@PathVariable Integer id, @RequestBody SuperMarket supermarket) {
		SuperMarket storedSuperMarket = superMarketService.getSuperMarketById(id);
		storedSuperMarket.setShopName(supermarket.getShopName());
		storedSuperMarket.setCategory(supermarket.getCategory());
		storedSuperMarket.setAddress(supermarket.getAddress());
		superMarketService.saveSuperMarket(storedSuperMarket);
		return new ResponseEntity("SuperMarket updated successfully", HttpStatus.OK);
	}

	@ApiOperation(value = "Delete a supermarket")
	@RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE, produces = "application/json")
	public ResponseEntity delete(@PathVariable Integer id) {
		superMarketService.deleteSuperMarket(id);
		return new ResponseEntity("Supermarket deleted successfully", HttpStatus.OK);

	}

}
