package com.gce.supermarket.repository;

import com.gce.supermarket.model.SuperMarket;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource
public interface SuperMarketRepository extends CrudRepository<SuperMarket, Integer>{

}
