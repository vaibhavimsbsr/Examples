package com.gce.supermarket.services;

import com.gce.supermarket.model.SuperMarket;

public interface SuperMarketService {
    Iterable<SuperMarket> listAllSuperMarket();

    SuperMarket getSuperMarketById(Integer id);

    SuperMarket saveSuperMarket(SuperMarket superMarket);

    void deleteSuperMarket(Integer id);
}
