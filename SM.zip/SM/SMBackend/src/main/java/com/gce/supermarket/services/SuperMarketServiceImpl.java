package com.gce.supermarket.services;

import com.gce.supermarket.model.SuperMarket;
import com.gce.supermarket.repository.SuperMarketRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SuperMarketServiceImpl implements SuperMarketService{
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private SuperMarketRepository superMarketRepository;
    
    @Autowired
    public void setSuperMarketRepository(SuperMarketRepository superMarketRepository) {
        this.superMarketRepository = superMarketRepository;
    }

	@Override
	public Iterable<SuperMarket> listAllSuperMarket() {
		logger.debug("listAll supermarket called");
        return superMarketRepository.findAll();
	}

	@Override
	public SuperMarket getSuperMarketById(Integer id) {
		logger.debug("getSuperMarketById called");
        return superMarketRepository.findById(id).orElse(null);
	}

	@Override
	public SuperMarket saveSuperMarket(SuperMarket superMarket) {
		logger.debug("saveSuperMarket called");
        return superMarketRepository.save(superMarket);
	}

	@Override
	public void deleteSuperMarket(Integer id) {
		logger.debug("delete SuperMarket called");
		superMarketRepository.deleteById(id);
	}

}
