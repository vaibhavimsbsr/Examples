'use strict';

angular.module('myApp').controller('MarketController', ['$scope', 'MarketService', function($scope, MarketService) {
    var self = this;
    self.market={id:null,marketname:'',address:'',email:''};
    self.markets=[];

    self.submit = submit;
    self.edit = edit;
    self.remove = remove;
    self.reset = reset;


    fetchAllMarkets();

    function fetchAllMarkets(){
        MarketService.fetchAllMarkets()
            .then(
            function(d) {
                self.markets = d;
            },
            function(errResponse){
                console.error('Error while fetching Markets');
            }
        );
    }

    function createMarket(market){
        MarketService.createMarket(market)
            .then(
            fetchAllMarkets,
            function(errResponse){
                console.error('Error while creating Market');
            }
        );
        fetchAllMarkets();
    }

    function updateMarket(market, id){
        MarketService.updateMarket(market, id)
            .then(
            fetchAllMarkets,
            function(errResponse){
                console.error('Error while updating Market');
            }
        );
    }

    function deleteMarket(id){
        MarketService.deleteMarket(id)
            .then(
            fetchAllMarkets,
            function(errResponse){
                console.error('Error while deleting Market');
            }
        );
        fetchAllMarkets();
    }

    function submit() {
        if(self.market.id===null){
            console.log('Saving New Market', self.market);
            createMarket(self.market);
        }else{
            updateMarket(self.market, self.market.id);
            console.log('Market updated with id ', self.market.id);
        }
        reset();
        fetchAllMarkets();
    }

    function edit(id){
        console.log('id to be edited', id);
        for(var i = 0; i < self.markets.length; i++){
            if(self.markets[i].id === id) {
                self.market = angular.copy(self.markets[i]);
                break;
            }
        }
    }

    function remove(id){
        console.log('id to be deleted', id);
        if(self.market.id === id) {//clean form if the market to be deleted is shown there.
            reset();
        }
        deleteMarket(id);
        fetchAllMarkets();
    }


    function reset(){
        self.market={id:null,marketname:'',address:'',email:''};
        $scope.myForm.$setPristine(); //reset Form
    }

}]);
