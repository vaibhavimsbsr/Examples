'use strict';

angular.module('myApp').factory('MarketService', ['$http', '$q', function($http, $q){

    var REST_SERVICE_URI = 'http://localhost:8080/supermarket/';
    var REST_SERVICE_URI1 = 'http://localhost:8080/supermarket/list/';
    var REST_SERVICE_URI2 = 'http://localhost:9080/SuperMarketFE/user/';
    
    var headers = {
			'Access-Control-Allow-Origin' : '*',
			'Access-Control-Allow-Methods' : 'POST, GET, OPTIONS, PUT',
			'Content-Type': 'application/json',
			'Accept': 'application/json'
		};

    var factory = {
        fetchAllMarkets: fetchAllMarkets,
        createMarket: createMarket,
        updateMarket:updateMarket,
        deleteMarket:deleteMarket
    };

    return factory;

    function fetchAllMarkets() {
        var deferred = $q.defer();
        $http.get(REST_SERVICE_URI+'list/', headers)
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while fetching Markets');
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }

    function createMarket(market) {
        var deferred = $q.defer();
        $http.post(REST_SERVICE_URI+'add/', market)
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while creating Market');
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }


    function updateMarket(market, id) {
        var deferred = $q.defer();
        $http.put(REST_SERVICE_URI+'update/'+id, market)
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while updating Market');
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }

    function deleteMarket(id) {
        var deferred = $q.defer();
        $http.delete(REST_SERVICE_URI+'delete/'+id)
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while deleting Market');
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }

}]);
